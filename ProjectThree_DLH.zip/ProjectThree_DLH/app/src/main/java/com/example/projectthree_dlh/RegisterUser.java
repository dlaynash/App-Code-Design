package com.example.projectthree_dlh;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterUser extends AppCompatActivity implements View.OnClickListener {

    private TextView loginReturn, registerUser;
    private EditText editTextFullName,editTextEmail, editTextPassword;
    private ProgressBar progressBarReg;

    private FirebaseAuth mAuth;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        // ...
        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        loginReturn = (TextView) findViewById(R.id.loginReturn);
        loginReturn.setOnClickListener(this);

        registerUser = (Button) findViewById(R.id.registerUser);
        registerUser.setOnClickListener(this);

        editTextFullName = (EditText) findViewById(R.id.fullNameReg);
        editTextEmail = (EditText) findViewById(R.id.emailReg);
        editTextPassword = (EditText) findViewById(R.id.passwordReg);

        progressBarReg = (ProgressBar) findViewById(R.id.progressBarReg);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.loginReturn:
                startActivity(new Intent(this, MainActivity.class));
                break;
            case R.id.registerUser:
                registerUser();
                break;
        }
    }

    private void registerUser() {
        String emailReg =editTextEmail.getText().toString().trim();
        String fullNameReg =editTextFullName.getText().toString().trim();
        String passwordReg =editTextPassword.getText().toString().trim();

        if(fullNameReg.isEmpty()){
            editTextFullName.setError("Please enter your full name.");
            editTextFullName.requestFocus();
            return;
        }

        if(emailReg.isEmpty()) {
            editTextEmail.setError("Email is required.");
            editTextEmail.requestFocus();
            return;
        }
        if(passwordReg.isEmpty()) {
            editTextPassword.setError("Password is required.");
            editTextPassword.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(emailReg).matches()){
            editTextEmail.setError("Please enter a valid email.");
            editTextEmail.requestFocus();
            return;
        }
        if(passwordReg.length() < 8){
            editTextPassword.setError("That password is too short, please choose a different password!");
            editTextPassword.requestFocus();
            return;
        }

        progressBarReg.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(emailReg, passwordReg)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            User user = new User(fullNameReg, emailReg);

                            FirebaseDatabase.getInstance().getReference("Users")
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful()){
                                                Toast.makeText(RegisterUser.this, "User has been registered.", Toast.LENGTH_LONG).show();
                                                progressBarReg.setVisibility(View.GONE);
                                            }else{
                                                Toast.makeText(RegisterUser.this, "The user was NOT registered.", Toast.LENGTH_LONG).show();
                                                progressBarReg.setVisibility(View.GONE);
                                            }
                                        }
                                    });
                        }else{Toast.makeText(RegisterUser.this, "The user was NOT registered.", Toast.LENGTH_LONG).show();
                            progressBarReg.setVisibility(View.GONE);
                        }
                    }
                });
    }
}