package com.example.projectthree_dlh;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DataEdits extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_edits);
    }
}