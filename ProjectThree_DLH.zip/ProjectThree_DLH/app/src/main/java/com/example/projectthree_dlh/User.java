package com.example.projectthree_dlh;

public class User {
    public String fullNameReg, emailReg;

    public User(){

    }
    public User(String fullNameReg, String emailReg){
        this.fullNameReg = fullNameReg;
        this.emailReg = emailReg;
    }
}
